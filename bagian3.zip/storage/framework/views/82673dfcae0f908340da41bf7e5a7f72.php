

<?php $__env->startSection('title'); ?>
    Tentang Kami
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    

    <!-- Main Start -->
    <section class="section bg-light mt-5" id="main">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="text-center mb-5">
                        <h5 class="text-primary">Tentang Kami</h5>
                        <h3>Apa itu Cair?</h3>
                        <hr class="text-primary border-1">
                        <P class=" opacity-75">Selaku agen leasing terbaik dan terpercaya di Indonesia. Kami
                            (Temangadai.com) menawarkan produk pinjaman gadai Sertifikat Rumah / Tanah (SHM). Yang
                            pencairannya bisa langsung ke konsumen.</P>
                        <P class=" opacity-75">Selain itu, proses yang dibutuhkan sangatlah cepat. Serta tenor sangat
                            fleksibel yang bisa disesuaikan menurut kemampuan konsumen. Selanjutnya, konsumen akan kami
                            referensikan ke Bank & Perusahaan pembiayaan rekanan yang resmi dan di awasi OJK.</P>
                        <P class=" opacity-75">Punya sertifikat rumah tapi tidak tau tempat gadai yang tepat? Kami bisa
                            memberi solusinya!</P>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Main End -->




    <!-- CTA End -->
    <Section class="section bg-soft-primary cta" id="cta">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="text-center mb-5">
                        <h2>Tunggu Apa Lagi ?</h2>
                        <P class="text-muted">Segera Hubungi Kami Untuk Pengajuan Gadai BPKB</P>
                        <h5 class="text-primary">Proses Cepat Tanpa Survey</h5>
                        <a href="https://api.whatsapp.com/send?phone=6281331111111" target="_blank"
                            class="btn btn-success mt-4 text-white w-100 f-16 rounded-pill p-3 px-5 fw-bold"><i
                                class="bi bi-whatsapp"></i> Hubungi Kami</a>
                    </div>
                </div>
            </div>
        </div>
    </Section>
    <!-- CTA End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Kerjaan\Aplikasi Cair\app\resources\views/frontend/pages/tentang-kami/index.blade.php ENDPATH**/ ?>