<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Premium Bootstrap 4 Landing Page Template" />
    <meta name="keywords" content="bootstrap 4, premium, marketing, multipurpose" />
    <meta content="Themesdesign" name="author" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- favicon -->
    <link rel="shortcut icon" href="images/favicon.ico">

    
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- css -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/style.min.css')); ?>" rel="stylesheet" type="text/css" />
    


    <!-- Pe-7 icon -->
    <link href="<?php echo e(asset('assets/css/pe-icon-7.css')); ?>" rel="stylesheet" type="text/css" />
    <!--Slider-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>" />

    <?php echo $__env->yieldPushContent('css'); ?>





</head>

<body>

    <!-- Loader -->
    <div id="preloader">
        <div id="status">
            <div class="spinner">
                <div class="bounce1"></div>
                <div class="bounce2"></div>
                <div class="bounce3"></div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('frontend.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Navbar End -->

    <div class="button-wa">
        <a href="https://wa.me/6281806942266/?text=Halo Kak Saya Ingin Bertanya"><i class="bi bi-whatsapp"></i></a>
    </div>
    <main>
        <?php echo $__env->yieldContent('content'); ?>

    </main>


    <!-- Footer Start -->
    <?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer End -->
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <!-- javascript -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    
    <!-- feather icons -->
    <script src="https://unpkg.com/feather-icons"></script>

    <script src="<?php echo e(asset('assets/js/contact.js')); ?>"></script>

    <!-- carousel -->
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>

    <!-- Choices.js -->
    <script src="<?php echo e(asset('build/libs/choices.js/public/assets/scripts/choices.min.js')); ?>"></script>

    <!-- Main Js -->
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>


</body>

</html>
<?php /**PATH C:\Kerjaan\Aplikasi Cair\app\resources\views/frontend/layouts/master.blade.php ENDPATH**/ ?>