<form action="" method="POST">
    <?php echo csrf_field(); ?>
    
    
    <div class="form-group mb-2">
        <label for="nama_mobil" class="form-label">Merk Mobil</label>
        <div class="d-flex align-items-center gap-4">
            <input type="text" class="form-control" placeholder="Masukan Merk Mobil" id="merk" name="merk[]">
            <a href="javascript:void(0)" class="btn btn-subtle-primary waves-effect waves-light btn-sm d-flex"
                id="btn-add-other-merk"><i class="bi bi-plus-circle me-2"></i>Add</a>
        </div>
        <?php $__errorArgs = ['merk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <!-- Tempat untuk input tambahan -->
    <div class="additional-inputs"></div>

    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        <button type="button" class="btn btn-primary" id="btn_save_merk">Simpan</button>
    </div>
</form>
<?php /**PATH C:\Kerjaan\Aplikasi Cair\app\resources\views/backend/mobil/create-merk.blade.php ENDPATH**/ ?>