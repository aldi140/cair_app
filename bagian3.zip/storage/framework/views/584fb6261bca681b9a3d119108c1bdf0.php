<!-- JAVASCRIPT -->
<script src="<?php echo e(asset('build/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('build/libs/metismenujs/metismenujs.min.js')); ?>"></script>
<script src="<?php echo e(asset('build/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('build/libs/eva-icons/eva.min.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<?php /**PATH C:\Kerjaan\Aplikasi Cair\app\resources\views/layouts/vendor-scripts.blade.php ENDPATH**/ ?>